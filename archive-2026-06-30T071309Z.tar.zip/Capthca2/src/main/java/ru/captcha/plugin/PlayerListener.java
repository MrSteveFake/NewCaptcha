package ru.captcha.plugin;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;

public class PlayerListener implements Listener {
    
    private final CaptchaPlugin plugin;
    
    public PlayerListener(CaptchaPlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        
        if (!plugin.getCaptchaManager().isVerified(player) && 
            !player.hasPermission("captcha.bypass")) {
            
            event.setCancelled(true);
            
            if (plugin.getCaptchaManager().hasSession(player)) {
                player.sendMessage(plugin.getMessage("messages.send-link"));
            } else {
                plugin.getServer().getScheduler().runTask(plugin, () -> 
                    plugin.getCaptchaManager().startCaptcha(player)
                );
            }
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        String command = event.getMessage().toLowerCase();
        
        if (!plugin.getCaptchaManager().isVerified(player) && 
            !player.hasPermission("captcha.bypass")) {
            
            if (!command.startsWith("/login") &&
                !command.startsWith("/register") &&
                !command.startsWith("/l ") &&
                !command.startsWith("/reg ")) {
                
                event.setCancelled(true);
                player.sendMessage("§c⚠ Вы должны пройти проверку captcha!");
                player.sendMessage("§7Перейдите по ссылке из чата для верификации");
            }
        }
    }
    
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        
        if (!player.hasPermission("captcha.bypass")) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> 
                plugin.getCaptchaManager().startCaptcha(player), 20L
            );
        }
    }
    
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        
        plugin.getCaptchaManager().failVerification(player);
        
        if (plugin.getLimboManager().isInLimbo(player)) {
            plugin.getLimboManager().returnFromLimbo(player);
        }
    }
    
    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        
        if (plugin.getLimboManager().isInLimbo(player) && 
            !plugin.getCaptchaManager().isVerified(player) &&
            plugin.getConfig().getBoolean("limbo.freeze-player", true)) {
            
            if (event.getFrom().getX() != event.getTo().getX() || 
                event.getFrom().getZ() != event.getTo().getZ()) {
                event.setCancelled(true);
            }
        }
    }
    
    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        if (plugin.getLimboManager().isInLimbo(event.getPlayer())) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        if (plugin.getLimboManager().isInLimbo(event.getPlayer())) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player player) {
            if (plugin.getLimboManager().isInLimbo(player)) {
                event.setCancelled(true);
            }
        }
    }
    
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player player) {
            if (plugin.getLimboManager().isInLimbo(player) &&
                !plugin.getCaptchaManager().isVerified(player)) {
                event.setCancelled(true);
            }
        }
    }
}