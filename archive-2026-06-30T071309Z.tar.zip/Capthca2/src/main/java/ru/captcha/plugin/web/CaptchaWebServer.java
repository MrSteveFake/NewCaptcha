package ru.captcha.plugin.web;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpsConfigurator;
import com.sun.net.httpserver.HttpsServer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import ru.captcha.plugin.CaptchaPlugin;

import javax.net.ssl.*;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.HashMap;
import java.util.Map;

public class CaptchaWebServer {
    
    private final CaptchaPlugin plugin;
    private final int port;
    private HttpsServer server;
    
    public CaptchaWebServer(CaptchaPlugin plugin, int port) {
        this.plugin = plugin;
        this.port = port;
    }
    
    public void start() {
        try {
            server = HttpsServer.create(new InetSocketAddress(port), 0);
            
            SSLContext sslContext = createSSLContext();
            server.setHttpsConfigurator(new HttpsConfigurator(sslContext));
            
            server.createContext("/verify", new VerifyHandler());
            server.createContext("/captcha", new CaptchaPageHandler());
            
            server.setExecutor(null);
            server.start();
            
            plugin.getLogger().info("HTTPS веб-сервер запущен на порту " + port);
        } catch (Exception e) {
            plugin.getLogger().severe("Не удалось запустить HTTPS веб-сервер: " + e.getMessage());
            plugin.getLogger().warning("Попытка запуска HTTP сервера как fallback...");
            startFallbackHTTP();
        }
    }
    
    private void startFallbackHTTP() {
        try {
            com.sun.net.httpserver.HttpServer httpServer = 
                com.sun.net.httpserver.HttpServer.create(new InetSocketAddress(port), 0);
            
            httpServer.createContext("/verify", new VerifyHandler());
            httpServer.createContext("/captcha", new CaptchaPageHandler());
            
            httpServer.setExecutor(null);
            httpServer.start();
            
            plugin.getLogger().warning("HTTP веб-сервер запущен на порту " + port);
        } catch (Exception e) {
            plugin.getLogger().severe("Не удалось запустить HTTP сервер: " + e.getMessage());
        }
    }
    
    private SSLContext createSSLContext() throws Exception {
        File keyStoreFile = new File(plugin.getDataFolder(), "keystore.jks");
        
        if (!keyStoreFile.exists()) {
            plugin.getLogger().info("Создаю самоподписанный сертификат...");
            generateSelfSignedCertificate();
        }
        
        KeyStore keyStore = KeyStore.getInstance("JKS");
        String password = plugin.getConfig().getString("recaptcha.verification-server.keystore-password", "changeit");
        
        try (FileInputStream fis = new FileInputStream(keyStoreFile)) {
            keyStore.load(fis, password.toCharArray());
        }
        
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(keyStore, password.toCharArray());
        
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(keyStore);
        
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);
        
        return sslContext;
    }
    
    private void generateSelfSignedCertificate() {
        try {
            String password = plugin.getConfig().getString("recaptcha.verification-server.keystore-password", "changeit");
            String domain = plugin.getConfig().getString("recaptcha.verification-server.domain", "localhost");
            
            File keyStoreFile = new File(plugin.getDataFolder(), "keystore.jks");
            
            ProcessBuilder pb = new ProcessBuilder(
                "keytool",
                "-genkeypair",
                "-alias", "captcha-server",
                "-keyalg", "RSA",
                "-keysize", "2048",
                "-validity", "365",
                "-keystore", keyStoreFile.getAbsolutePath(),
                "-storepass", password,
                "-keypass", password,
                "-dname", "CN=" + domain + ", OU=CaptchaPlugin, O=Minecraft, L=City, ST=State, C=RU"
            );
            
            Process process = pb.start();
            process.waitFor();
            
            plugin.getLogger().info("Самоподписанный сертификат создан!");
        } catch (Exception e) {
            plugin.getLogger().severe("Ошибка при создании сертификата: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }
    
    public void stop() {
        if (server != null) {
            server.stop(0);
            plugin.getLogger().info("HTTPS веб-сервер остановлен");
        }
    }
    
    private class CaptchaPageHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String playerName = getQueryParam(exchange, "player");
            String siteKey = plugin.getConfig().getString("recaptcha.site-key");
            String html = generateCaptchaPage(siteKey, playerName);
            
            exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
            exchange.sendResponseHeaders(200, html.getBytes(StandardCharsets.UTF_8).length);
            
            OutputStream os = exchange.getResponseBody();
            os.write(html.getBytes(StandardCharsets.UTF_8));
            os.close();
        }
    }
    
    private class VerifyHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equals(exchange.getRequestMethod())) {
                String playerName = getQueryParam(exchange, "player");
                String siteKey = plugin.getConfig().getString("recaptcha.site-key");
                String html = generateCaptchaPage(siteKey, playerName);
                
                exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
                exchange.sendResponseHeaders(200, html.getBytes(StandardCharsets.UTF_8).length);
                
                OutputStream os = exchange.getResponseBody();
                os.write(html.getBytes(StandardCharsets.UTF_8));
                os.close();
                
            } else if ("POST".equals(exchange.getRequestMethod())) {
                String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
                Map<String, String> params = parseFormData(body);
                
                String token = params.get("g-recaptcha-response");
                String playerName = params.get("player");
                
                String response;
                if (token != null && playerName != null) {
                    Player player = Bukkit.getPlayer(playerName);
                    
                    if (player != null && plugin.getCaptchaManager().hasSession(player)) {
                        boolean verified = verifyWithGoogle(token);
                        
                        if (verified) {
                            plugin.getCaptchaManager().handleSuccessfulVerification(player);
                            response = generateSuccessPage();
                        } else {
                            response = generateErrorPage("Неверная капча. Попробуйте еще раз.");
                        }
                    } else {
                        response = generateErrorPage("Игрок не найден или сессия истекла.");
                    }
                } else {
                    response = generateErrorPage("Отсутствуют необходимые параметры.");
                }
                
                exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
                exchange.sendResponseHeaders(200, response.getBytes(StandardCharsets.UTF_8).length);
                
                OutputStream os = exchange.getResponseBody();
                os.write(response.getBytes(StandardCharsets.UTF_8));
                os.close();
            }
        }
    }
    
    private boolean verifyWithGoogle(String token) {
        try {
            String secretKey = plugin.getConfig().getString("recaptcha.secret-key");
            String url = "https://www.google.com/recaptcha/api/siteverify";
            
            HttpClient client = HttpClient.newHttpClient();
            String formData = "