package ru.captcha.plugin;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.jetbrains.annotations.NotNull;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class LimboManager {
    
    private final CaptchaPlugin plugin;
    private World limboWorld;
    private final String worldName;
    private final Map<UUID, Location> previousLocations = new ConcurrentHashMap<>();
    private final Map<UUID, ItemStack[]> savedInventories = new ConcurrentHashMap<>();
    private final Map<UUID, GameMode> savedGameModes = new ConcurrentHashMap<>();
    
    public LimboManager(CaptchaPlugin plugin) {
        this.plugin = plugin;
        this.worldName = plugin.getConfig().getString("limbo.world-name", "captcha_limbo");
    }
    
    public void initLimboWorld() {
        World existingWorld = Bukkit.getWorld(worldName);
        if (existingWorld != null) {
            limboWorld = existingWorld;
            return;
        }
        
        WorldCreator creator = new WorldCreator(worldName);
        creator.environment(World.Environment.NORMAL);
        creator.type(WorldType.FLAT);
        creator.generateStructures(false);
        creator.generator(new VoidGenerator());
        
        limboWorld = creator.createWorld();
        
        if (limboWorld != null) {
            limboWorld.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
            limboWorld.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
            limboWorld.setGameRule(GameRule.DO_MOB_SPAWNING, false);
            limboWorld.setGameRule(GameRule.ANNOUNCE_ADVANCEMENTS, false);
            limboWorld.setGameRule(GameRule.DO_FIRE_TICK, false);
            limboWorld.setGameRule(GameRule.MOB_GRIEFING, false);
            limboWorld.setGameRule(GameRule.RANDOM_TICK_SPEED, 0);
            limboWorld.setGameRule(GameRule.SPAWN_RADIUS, 0);
            limboWorld.setTime(6000);
            limboWorld.setDifficulty(Difficulty.PEACEFUL);
            limboWorld.setSpawnLocation(0, 100, 0);
        }
        
        plugin.getLogger().info("§aLimbo мир '" + worldName + "' успешно создан!");
    }
    
    public void sendToLimbo(Player player) {
        if (limboWorld == null) {
            initLimboWorld();
        }
        
        if (limboWorld == null) {
            plugin.getLogger().warning("§cНе удалось создать/найти Limbo мир!");
            return;
        }
        
        previousLocations.put(player.getUniqueId(), player.getLocation());
        savedGameModes.put(player.getUniqueId(), player.getGameMode());
        
        if (plugin.getConfig().getBoolean("limbo.clear-inventory", false)) {
            savedInventories.put(player.getUniqueId(), player.getInventory().getContents());
            player.getInventory().clear();
        }
        
        int spawnHeight = plugin.getConfig().getInt("limbo.spawn-height", 100);
        Location limboLocation = new Location(limboWorld, 0, spawnHeight, 0);
        
        if (!limboLocation.getChunk().isLoaded()) {
            limboLocation.getChunk().load();
        }
        
        player.teleport(limboLocation);
        player.setGameMode(GameMode.ADVENTURE);
        player.setAllowFlight(true);
        player.setFlying(true);
        
        if (plugin.getConfig().getBoolean("limbo.blindness", true)) {
            player.addPotionEffect(new PotionEffect(
                    PotionEffectType.BLINDNESS, 
                    Integer.MAX_VALUE, 
                    1, 
                    false, 
                    false
            ));
        }
        
        player.addPotionEffect(new PotionEffect(
                PotionEffectType.SLOW_FALLING,
                Integer.MAX_VALUE,
                1,
                false,
                false
        ));
        
        player.sendMessage(plugin.getMessage("messages.limbo-enter"));
    }
    
    public void returnFromLimbo(Player player) {
        UUID uuid = player.getUniqueId();
        
        player.removePotionEffect(PotionEffectType.BLINDNESS);
        player.removePotionEffect(PotionEffectType.SLOW_FALLING);
        
        if (savedInventories.containsKey(uuid)) {
            player.getInventory().setContents(savedInventories.get(uuid));
            savedInventories.remove(uuid);
        }
        
        Location returnLocation = previousLocations.getOrDefault(uuid, 
                Bukkit.getWorlds().get(0).getSpawnLocation());
        
        if (returnLocation.getWorld() == limboWorld) {
            returnLocation = Bukkit.getWorlds().get(0).getSpawnLocation();
        }
        
        if (!returnLocation.getChunk().isLoaded()) {
            returnLocation.getChunk().load();
        }
        
        player.teleport(returnLocation);
        player.setAllowFlight(false);
        player.setFlying(false);
        
        GameMode previousGameMode = savedGameModes.getOrDefault(uuid, GameMode.SURVIVAL);
        player.setGameMode(previousGameMode);
        
        previousLocations.remove(uuid);
        savedGameModes.remove(uuid);
        
        player.sendMessage(plugin.getMessage("messages.limbo-leave"));
    }
    
    public boolean isInLimbo(Player player) {
        return player.getWorld().equals(limboWorld);
    }
    
    private static class VoidGenerator extends ChunkGenerator {
        @Override
        public @NotNull ChunkData generateChunkData(
                @NotNull World world, 
                @NotNull Random random, 
                int x, 
                int z, 
                @NotNull BiomeGrid biome) {
            
            ChunkData chunkData = createChunkData(world);
            
            for (int blockX = 0; blockX < 16; blockX++) {
                for (int blockZ = 0; blockZ < 16; blockZ++) {
                    biome.setBiome(blockX, blockZ, Biome.PLAINS);
                }
            }
            
            return chunkData;
        }
    }
}