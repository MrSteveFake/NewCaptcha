package ru.captcha.plugin;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import ru.captcha.plugin.web.CaptchaWebServer;

public class CaptchaPlugin extends JavaPlugin {
    
    private static CaptchaPlugin instance;
    private CaptchaManager captchaManager;
    private LimboManager limboManager;
    private CaptchaWebServer webServer;
    
    @Override
    public void onEnable() {
        instance = this;
        
        saveDefaultConfig();
        
        captchaManager = new CaptchaManager(this);
        limboManager = new LimboManager(this);
        
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        
        if (getConfig().getBoolean("limbo.enabled", true)) {
            Bukkit.getScheduler().runTask(this, () -> limboManager.initLimboWorld());
        }
        
        if (getConfig().getBoolean("recaptcha.verification-server.enabled", false)) {
            startWebServer();
        }
        
        getLogger().info("§aCaptchaPlugin успешно включен!");
        getLogger().info("§aВерсия: " + getDescription().getVersion());
    }
    
    @Override
    public void onDisable() {
        if (webServer != null) {
            webServer.stop();
        }
        
        if (limboManager != null) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (limboManager.isInLimbo(player)) {
                    limboManager.returnFromLimbo(player);
                }
            }
        }
        
        if (captchaManager != null) {
            captchaManager.cleanup();
        }
        
        getLogger().info("§cCaptchaPlugin выключен!");
    }
    
    private void startWebServer() {
        int port = getConfig().getInt("recaptcha.verification-server.port", 8443);
        webServer = new CaptchaWebServer(this, port);
        webServer.start();
        getLogger().info("§aВеб-сервер верификации запущен на порту " + port);
    }
    
    public static CaptchaPlugin getInstance() {
        return instance;
    }
    
    public CaptchaManager getCaptchaManager() {
        return captchaManager;
    }
    
    public LimboManager getLimboManager() {
        return limboManager;
    }
    
    public String getMessage(String path) {
        return getConfig().getString(path, "").replace("&", "§");
    }
}